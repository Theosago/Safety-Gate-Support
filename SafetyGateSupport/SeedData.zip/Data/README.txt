Shared Safety Gate Support data. This folder is managed by SafetyGateSupport.exe.
